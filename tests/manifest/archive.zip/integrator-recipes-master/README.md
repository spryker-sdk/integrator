# integrator-recipes

Recipes for [SprykerSdk.Integrator](https://github.com/spryker-sdk/integrator) module.
They contain machine-readable intructions on how to integrate core module updates into project level.
This aims to help automating the process.
